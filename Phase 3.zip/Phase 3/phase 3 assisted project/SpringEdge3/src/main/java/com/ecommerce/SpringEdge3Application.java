package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEdge3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringEdge3Application.class, args);
	}

}
